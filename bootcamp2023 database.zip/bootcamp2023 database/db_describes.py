#step1
import sqlite3
#step2 and step3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
'''
describe tablename->in mysql
pragma tableinfo(tablename)->squlite3
'''
query='''
pragma table_info(participants)
'''
details=conn.execute(query)
print(details)
for i in details:
    print(i)

conn.commit()
conn.close()