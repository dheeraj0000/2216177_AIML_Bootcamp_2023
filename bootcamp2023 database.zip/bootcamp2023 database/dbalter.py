#step1
import sqlite3
#step2 and step3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

conn.execute('alter table participants add column mail_id text not null')
conn.connect()
conn.close()

'''
changing the datatype of already given attributes
remaning the attributes
alter table table_name rename column old_name to new_name
'''