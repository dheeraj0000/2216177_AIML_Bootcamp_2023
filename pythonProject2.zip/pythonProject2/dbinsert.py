import sqlite3
#step2 and step3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

conn.execute ("insert into participants values(2216173,'Akshay','CSE','Betch','akshay@2003')")
conn.execute ("insert into participants values(2216174,'Dheeraj','CSE','Betch','Dheeraj@2003')")
conn.execute ("insert into participants values(2216175,'rohith','CSE','Betch','rohith@2003')")
conn.execute ("insert into participants values(2216178,'ajay','ECE','Betch','ajay@2003')")
conn.execute ("insert into participants values(2216176,'rao','ECE','Betch','raok@2003')")
print(conn.total_changes)

conn.commit()
conn.close()