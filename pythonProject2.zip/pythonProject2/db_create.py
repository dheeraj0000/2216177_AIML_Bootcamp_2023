#steps
"""
1.importing the moudle
2.create a database
3.establish the connection with database
4.creating a table in the database-participates-writing the query
5.execute the query
"""
#step1
import sqlite3
#step2 and step3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")

#step4
query='''create table participants(Gid int primary key,name text not null,branch text not null,study text not null)'''

conn.execute(query)
