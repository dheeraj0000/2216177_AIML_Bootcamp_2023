import sqlite3
#step2 and step3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
print(conn)

conn.execute("update participants set name='akshayrao' where gid=2216173")
conn.commit()
conn.close()